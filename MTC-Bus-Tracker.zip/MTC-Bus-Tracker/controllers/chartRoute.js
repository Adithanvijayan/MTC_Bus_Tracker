exports.ChartGet = (req,res) =>{
    res.render('chart');
}